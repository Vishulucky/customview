package com.example.vishalkamboj.customeviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by vishalkamboj on 05/01/18.
 */

public class SecondCustom extends View {

    private int shapes;
    private float dimen;
    private Paint paint;

    private static final int CICLESHAPE = 0;
    private static final int SQUARESHAPE =1;

    public SecondCustom(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        TypedArray typedArray = context.obtainStyledAttributes(attrs,R.styleable.SecondCustomView);


        try{


            shapes = typedArray.getInteger(R.styleable.SecondCustomView_custom_shapes,0);
            dimen = typedArray.getDimension(R.styleable.SecondCustomView_dimensionsval,12f);


            paint = new Paint();
            paint.setColor(getResources().getColor(R.color.orangeshade));




        }
        catch (Exception e)
        {

        }
        finally {

            typedArray.recycle();
        }





    }


    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        switch (shapes)
        {
            case CICLESHAPE:

                canvas.drawCircle(dimen,dimen,dimen,paint);

                break;


            case SQUARESHAPE:
                canvas.drawRect(0,0,dimen,dimen,paint);
                break;

        }







    }
}
