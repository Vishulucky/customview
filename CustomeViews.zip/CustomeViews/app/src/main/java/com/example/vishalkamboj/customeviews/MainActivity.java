package com.example.vishalkamboj.customeviews;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    private  SecondCustom circleshape;
    private  SecondCustom squareshape;
    private TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        circleshape = (SecondCustom)findViewById(R.id.circleshape);
        squareshape = (SecondCustom)findViewById(R.id.squareshape);
        textView = (TextView)findViewById(R.id.textval);

        circleshape.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                textView.setText("Circle Shape");



            }
        });

        squareshape.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                textView.setText("Square Shape");

            }
        });



    }
}
