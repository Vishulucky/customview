package com.example.vishalkamboj.customeviews;

import android.content.Context;
import android.content.res.TypedArray;
import android.support.annotation.Nullable;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by vishalkamboj on 05/01/18.
 */

public class CustomView extends View {

    private  int backcolor;

    public CustomView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);

        TypedArray typedArray = context.obtainStyledAttributes(attrs,R.styleable.CustomView);

         try {

             backcolor = typedArray.getColor(R.styleable.CustomView_background_color,0);
             setBackgroundColor(backcolor);



         }
         catch (Exception e)
         {

         }
         finally {

              typedArray.recycle();

               // Garbage Collection //




         }








    }



}
